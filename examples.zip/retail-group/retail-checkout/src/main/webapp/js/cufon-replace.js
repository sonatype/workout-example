Cufon.replace('#header ul li a', { fontFamily: 'Myriad Pro i', hover:true });
Cufon.replace('h2', { fontFamily: 'Myriad Pro si' })
Cufon.replace('h3', { fontFamily: 'Myriad Pro bl' })