package com.sonatype.workout.web.command;

import java.util.Date;

public class WorkoutCommand {
	
	private Date date;
	
	public WorkoutCommand() {}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
